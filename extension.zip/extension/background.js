// Optional — currently unused
chrome.runtime.onInstalled.addListener(() => {
    console.log("[AutoAccess] Extension installed");
  });